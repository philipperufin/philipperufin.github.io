---
title: "Projects"
date: 2020-10-20T18:55:12+03:30
headless: true
weight: 4
content_type: "projects"

section_settings:
    show_section: true
    title: ''
    subtitle: 'Custom Subtitle: see my github for the complete list'
---

home/projects.md