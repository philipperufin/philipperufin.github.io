---
title: "Quisque: Lime Trout Sheepdog"

date: "2018-05-18"

links:
    website: 'https://github.com/hadisinaee/avicenna'
    alias: link_name_here
---

