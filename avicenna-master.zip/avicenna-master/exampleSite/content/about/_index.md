---
title: "about"
date: 2020-10-20T17:51:47+03:30
draft: false
headless: true

full_name: "YOUR_NAME"
profile_picture: "profile.png"
cv: "cv.pdf"
# set to false if you don't want to show your blog
blog: true

socials:
    twitter: "YOUR_NAME"
    github: "YOUR_NAME"
    facebook: "YOUR_NAME"
    linkedin: "YOUR_NAME"
    twitch: "YOUR_NAME"
    google_scholar: "YOUR_NAME"

interests:
    - Data Intensive Systems
    - Distributed Systems
    - Data Streaming Platforms
    - Large-Scale Data Processing Platforms

affiliations:
    - affiliation:
        title: "Ph.D."
        name: "Stanford University"
        email: "email@cs.stanford.edu"
    - affiliation:
        title: "CEO & Co-Founder"
        name: "The Coolest Startup In the World"
        email: "email@mycoolstartup.ai"

academia:
    - course:
        degree: "Ph.D."
        institution:  "Stanford University"
        major: "Data Systems"
        start_date: "2021"
    - course:
        degree: "M.Sc."
        institution: 'Sharif University of Technology'
        major: 'Software Engineering'
        start_date: '2013'
        end_date: '2016'
        other_info: 'graduated without first class honor, supervised by Prof. Very Cool!'
    - course:
        degree: "B.Sc."
        institution: 'University of Kashan'
        major: 'Software Engineering'
        minor: 'Statistics'
        start_date: '2009'
        end_date: '2013'
        other_info: 'graduated with first class honor, supervised by Prof.  Cool!'
---

**Donec** sollicitudin, [ante][1] pulvinar tincidunt luctus, dolor mauris lobortis ex, id tincidunt metus risus nec ex. Curabitur magna mauris, facilisis vitae porttitor vitae, tincidunt sed mi. In at dui lectus. Integer ante arcu, vestibulum fermentum ante eu, maximus maximus quam. Curabitur placerat cursus posuere. Phasellus dui lorem, varius a augue non, eleifend accumsan mauris. Aenean varius posuere feugiat. In hac habitasse platea dictumst. Aenean quis ex quis nisl consequat fermentum in vitae nunc. Proin consectetur ac nulla in tempus. Maecenas enim nisi, pulvinar sit amet fermentum eget, ultrices vitae enim. Etiam vel sollicitudin felis.


Donec sollicitudin, ante pulvinar tincidunt luctus, dolor mauris lobortis ex, id tincidunt metus risus nec ex. Curabitur magna mauris, facilisis vitae porttitor vitae, 


[1]: ahadsfsa.com